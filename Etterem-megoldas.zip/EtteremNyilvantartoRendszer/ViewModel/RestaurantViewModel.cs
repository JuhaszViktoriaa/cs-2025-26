﻿using CommunityToolkit.Mvvm.ComponentModel;
using EtteremNyilvantartoRendszer.Model;
using EtteremNyilvantartoRendszer.Repo;
using System.Collections.ObjectModel;

namespace EtteremNyilvantartoRendszer.ViewModel
{
    public partial class RestaurantViewModel : ObservableObject
    {
        private readonly RestaurantRepo _repo = new RestaurantRepo();
        public ObservableCollection<Restaurant> Restaurants { get; }

        public RestaurantViewModel()
        {
            Restaurants = new ObservableCollection<Restaurant>(_repo.GetAll());

            // 1. Hány étterem van
            public int RestaurantCount => Restaurants.Count;
            
            // 2. Hány különböző tulajdonos
            public int OwnerCount => Restaurants.Select(r => r.Owner).Distinct().Count();
            
            // 3. Tulajdonosonként hány étterem van
            var eredmeny = Restaurants.GroupBy(r => r.Owner).Select(g => new { Owner g => g.Key, g.Count() });
            
            // 4. Hány olyan étterem van amelynek nevében benne van egy adót szórészlet?
            public int CountByName(string name) => Restaurants.Count(r => r.Name != null && r.Name.Contains(name));

            // Vegyük fel hogy egy étteremnek mennyi a bevétele

            // 1. Mennyi az összbevétel, átlagbevétel
            public decimal TotalRevenue => Restaurants.Sum(r => r.TotalRevenue);
            public decimal AvgRevenue => Restaurants.Any() ? Restaurants.Average(r => r.Revenue) : 0;

            // 2. Melyik étteremnek van a legnagyobb bevétele
            public Restaurant Highest => Restaurants.OrderByDescending(r => r.Bevetel).FirstOrDefault();
        }
    }
}
