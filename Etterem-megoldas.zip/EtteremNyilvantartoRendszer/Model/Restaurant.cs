﻿namespace EtteremNyilvantartoRendszer.Model
{
    public class Restaurant
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string OwnerName { get; set; } 
        public decimal Bevetel { get; set; }

        public Restaurant() { }

        public Restaurant(int id, string name, string ownerName, decimal bevetel)
        {
            Id = id;
            Name = name;
            OwnerName = ownerName;
            Bevetel = bevetel;
        }

        public override string ToString() => $"{Id} {Name} {OwnerName} {Bevetel}";
    }
}
