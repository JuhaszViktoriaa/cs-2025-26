﻿using EtteremNyilvantartoRendszer.Model;

namespace EtteremNyilvantartoRendszer.Repo
{
    public class RestaurantRepo
    {
        private List<Restaurant> _items = new()
        {
            new Restaurant(1,"Tisza Bistro","Kiss Gábor"),
            new Restaurant(2,"Paprika Csárda","Nagy Anna"),
            new Restaurant(3,"Rózsa Kert","Szabó László"),
            new Restaurant(4,"Fekete Macska Café","Tóth Eszter"),
            new Restaurant(5,"Halászlé Műhely","Varga Péter")
        };

        public IReadOnlyList<Restaurant> GetAll()
        {
            return _items.ToList();
        }
    }
}
